#*************** DRUVA TENANT PROFILER 1.0 ************
#Author: 			Babu Pillai / babu.pillai@druva.com
#Last Modified On:	04/22/2022

Function eo.load
{
	#Check if Exchange Online Management Module is installed. If not installed, it will be installed and imported to this session to use.
	module.check "ExchangeOnlineManagement"
	
	log.info "Connecting to Exchange Online..."
	if($mfa.IsPresent) #For MFA enabled environments
	{
		Connect-ExchangeOnline -ErrorAction Stop; #Connect to Exchange Online. This will open a window for user to enter credentials.
		if($_.Error)
		{
			log.error "Cannot connect to Exchange Online";
			exit;
		}
	}
	else #For non-MFA enabled environments
	{
		Connect-ExchangeOnline -Credential $global:cred -ErrorAction Stop; #Connect to Exchange Online with credentials
		if($_.Error)
		{
			log.error "Cannot connect to Exchange Online";
			exit;
		}
	}
	log.success "Connected to Exchange Online";
	Write-Host "";
}

#Get exchange mailbox information
Function eo.get
{    
	#Create Exchange Report
	output.create $EXCH_RPRT_NAME @("Type","Name","Items", "Size (MB)", "Active", "LitigationHold", "LastLogonDateTime", "ChangedDateTime","SoftDeletedDateTime","Archive Items","Archive Size(MB)","Mailbox Released?");
	
    $mailboxes = $null;	
	try
	{
		#Get all mailboxes in the environment
		$mailboxes = Get-Mailbox -ResultSize 1000000000 -IncludeInactiveMailbox | Select UserPrincipalName,RecipientTypeDetails,IsInactiveMailbox,WhenSoftDeleted,WhenChanged,LitigationHoldEnabled,MailboxRelease | Sort-Object UserPrincipalName
    }
	catch
	{
		
		eo.load
		#Get all mailboxes in the environment
		$mailboxes = Get-Mailbox -ResultSize 1000000000 -IncludeInactiveMailbox | Select UserPrincipalName,RecipientTypeDetails,IsInactiveMailbox,WhenSoftDeleted,WhenChanged,LitigationHoldEnabled,MailboxRelease | Sort-Object UserPrincipalName
	}
	$global:exchCount = $mailboxes.Count;
	log.success "Found $global:exchCount mailboxes";
	
    foreach($mailbox in $mailboxes) #Loop through mailbox collection
	{
		$mbName = $mailbox.UserPrincipalName;
		$mbType = $mailbox.RecipientTypeDetails;
		$mbIsActive = !$mailbox.IsInactiveMailbox;
		$mbItemCount = 0;
		$mbSize = 0;
		$mbLitigationHoldEnabled = $mailbox.LitigationHoldEnabled;
		$mbLastLogonTime = "";	
		$softDelDate = "";
		$mbChangedDate = "";	
		$isMailBoxReleased = ($mailbox.MailboxRelease -ne "");
				
		log.success "`t$mbName"		
		if($mailbox.IsInactiveMailbox -eq "True") #cannot get statistics for inactive mailbox; Default all values
		{
			$mbItemCount = 0;
			$mbSize = 0;
			$softDelDate = "$($mailbox.WhenSoftDeleted)";
		}
		else
		{
			#Get mailbox statistics
			$mailboxStat = Get-MailboxStatistics -Identity $mailbox.UserPrincipalName | Select ItemCount,TotalItemSize,LastLogonTime;
			#Get archive mailbox information
			$mailboxArchiveStat = Get-MailboxStatistics -Identity $mailbox.UserPrincipalName -Archive -WarningAction SilentlyContinue -ErrorAction SilentlyContinue | Select ItemCount,TotalItemSize
			
			$mbItemCount = $mailboxStat.ItemCount;
			$mbSize = getSize $mailboxStat.TotalItemSize;
			
			$mbArchiveItemCount = 0;
			$mbArchiveSize = 0;
			if($mailboxArchiveStat -ne $null)
			{
				$mbArchiveItemCount = $mailboxArchiveStat.ItemCount;
				$mbArchiveSize = getSize $mailboxArchiveStat.TotalItemSize;
				
				$global:archiveExchSize += $mbArchiveSize;
				$global:archiveExchCount++;
			}
			
			$mbChangedDate = "$($mailbox.WhenChanged)";
			$mbLastLogonTime = "$($mailboxStat.LastLogonTime)";			
		}
		#Write to Exchange report
		output.log $EXCH_RPRT_NAME $($mbType, $mbName, $mbItemCount, $mbSize, $mbIsActive, $mbLitigationHoldEnabled, $mbLastLogOnTime, $mbChangedDate, $softDelDate,$mbArchiveItemCount,$mbArchiveSize, $isMailBoxReleased);
		#Collect mailbox size. This will be used for global count
		$global:exchSize += $mbSize;
	}
	log.info "Completed Mailbox information"
}
#Below function will be used to get size information from Get-MailboxStatistics. Value returned will be on MB
Function getSize($mbTotalSize)
{
	$mbSize = 0;
	if($mbTotalSize -ne $null) 
	{
		$mbSize = $mbTotalSize.Value.ToString();
		
		if($mbSize.IndexOf(" MB") -ne -1){
			$mbSize = [math]::Round([double]$mbSize.SubString(0,$mbSize.IndexOf(" MB")),2);
		}
		elseif($mbSize.IndexOf(" KB") -ne -1){
			$mbSize = [math]::Round(([double]$mbSize.SubString(0,$mbSize.IndexOf(" KB"))) / 1024,2);
		}
		elseif($mbSize.IndexOf(" GB") -ne -1){
			$mbSize = [math]::Round(([double]$mbSize.SubString(0,$mbSize.IndexOf(" GB"))) * 1024,2);
		}
	}
	return $mbSize;
}
