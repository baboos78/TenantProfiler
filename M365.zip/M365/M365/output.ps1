#*************** DRUVA TENANT PROFILER 1.0 ************
#Author: 			Babu Pillai / babu.pillai@druva.com
#Last Modified On:	04/08/2022

$currentDirectory = (Get-Location).Path; #Current directory where powershell is being executed
$dateTimeNow = Get-Date -Format "MM-dd-yyyy_hh_mm"; #current date time
$global:outputFile = "$currentDirectory\Reports\Tenant_Information_$($tenant)_$($dateTimeNow).xlsx"; #unique output file path
if(!$keeplogs.IsPresent)
{
	$global:outputFile = "$currentDirectory\Reports\Tenant_Information.xlsx";
}

#Create Report. Based on the output format selected, either txt,csv or xls
Function output.create($worksheetName, $headers)
{	
	if($output -eq "txt")
	{
		$global:outputFile = "$currentDirectory\Reports\Tenant_Information_$($tenant)_$($worksheetName)_$($dateTimeNow).txt";
		if(!$keeplogs.IsPresent)
		{
			$global:outputFile = "$currentDirectory\Reports\Tenant_Information_$($worksheetName).txt";
		}
		New-Item $global:outputFile; #Create new text file (tab delimited)
		
		Add-Content -Path $global:outputFile -Value "$headers"; #Add headers to the newly created report.
	}
	elseif($output -eq "csv")
	{
		$global:outputFile = "$currentDirectory\Reports\Tenant_Information_$($tenant)_$($worksheetName)_$($dateTimeNow).csv";
		if(!$keeplogs.IsPresent)
		{
			$global:outputFile = "$currentDirectory\Reports\Tenant_Information_$($worksheetName).csv";
		}
		$headers -join "," | Add-Content -path $global:outputFile; #Create new CSV file and add headers
	}
	else
	{
		if(($global:workbook -eq $null) -OR ($global:workbook.Worksheets -eq $null))
		{
			try 
			{				
				$global:excel = New-Object -ComObject excel.application; #Create new excel file object. Object will be in the memory until it flushes out
			}
			catch
			{
				#Most probably no office in the running environment. This happens when code is executed on the server.
				log.error "Cannot create excel output. Check if office components are installed on this machine. Or else, try outputting using csv or txt";
				exit;
			}
			$global:workbook = $null;
			$global:wksht = $null;
			$global:rowNumber = 1; #starting with first row
			$global:colNumber = 1; #starting with first column
			
			log.info "Creating report file...";
			$global:excel.visible = $False; #Hide excel object
			$global:excel.DisplayAlerts = 'False'; #Hide user alerts
			$global:workbook = $global:excel.Workbooks.Add(); #Add new workbook
			$global:wksht = $global:workbook.Worksheets.Item(1); #Get default sheet
		}
		else 
		{
			$global:wksht= $global:workbook.Worksheets.Add(); #Create new worksheet
		}
		log.info "Creating $worksheetName sheet...";
		$global:wksht.Name = $worksheetName; #Rename worksheet to selected name
		$global:rowNumber = 1;#starting with first row
		$global:colNumber = 1;#starting with first column
		
		if($headers -ne $null)
		{		
			foreach($header in $headers)
			{
				#Create Header with special font
				$global:wksht.Cells.Item($global:rowNumber, $global:colNumber).Font.Size = 12;
				$global:wksht.Cells.Item($global:rowNumber, $global:colNumber).Font.Bold=$True;
				$global:wksht.Cells.Item($global:rowNumber, $global:colNumber).Font.Name = "Cambria";
				$global:wksht.Cells.Item($global:rowNumber, $global:colNumber).Font.ThemeFont = 1;
				$global:wksht.Cells.Item($global:rowNumber, $global:colNumber).Font.ThemeColor = 4;
				$global:wksht.Cells.Item($global:rowNumber, $global:colNumber).Font.ColorIndex = 55;
				$global:wksht.Cells.Item($global:rowNumber, $global:colNumber).Font.Color = 8210719;
				$global:wksht.Cells.Item($global:rowNumber, $global:colNumber) = $header;
				$global:colNumber++;
			}
		}
		else
		{
			log.info "Header is null"
		}
		$global:colNumber = 1; #Column remains the same. 
		$global:rowNumber++; #Moving to next row to add data
	}
}
#Append content to report
Function output.log($worksheetName,$dataArray)
{
	if($output -eq "txt")
	{		
		$global:outputFile = "$currentDirectory\Reports\Tenant_Information_$($worksheetName)_$($dateTimeNow).txt";
		if(!$keeplogs.IsPresent)
		{
			$global:outputFile = "$currentDirectory\Reports\Tenant_Information_$($worksheetName).txt";
		}
		Add-Content -Path $global:outputFile -Value "$dataArray"; #Add content to the txt file
	}
	elseif($output -eq "csv")
	{
		$global:outputFile = "$currentDirectory\Reports\Tenant_Information_$($worksheetName)_$($dateTimeNow).csv";
		if(!$keeplogs.IsPresent)
		{
			$global:outputFile = "$currentDirectory\Reports\Tenant_Information_$($worksheetName).csv";
		}
		($dataArray -replace ',','-') -join "," | add-content -path $global:outputFile; #Add content to the CSV file
	}
	else{
		#$global:wksht = $global:workbook.Worksheets.Item($worksheetName);
		
		if($dataArray -ne $null)
		{
			foreach($data in $dataArray) #Loop through the data
			{
				if($data -eq $null)
				{
					$data = "";
				}
				try
				{
					$global:wksht.Cells.Item($global:rowNumber, $global:colNumber) = $data;	#Add data to each cell
				}
				catch
				{
					Write-Host $_
				}

				$global:colNumber++; #Move to next column; row remain the same
			}
			$global:colNumber = 1; #Move position to first column
			$global:rowNumber++; #Move position to next row
		}
	}
}
#Append content to report as bold
Function output.logAsBold($worksheetName, $dataArray, $colorIndex)
{
	if($output -eq "txt")
	{		
		$global:outputFile = "$currentDirectory\Reports\Tenant_Information_$($worksheetName)_$($dateTimeNow).txt";
		if(!$keeplogs.IsPresent)
		{
			$global:outputFile = "$currentDirectory\Reports\Tenant_Information_$($worksheetName).txt";
		}
		Add-Content -Path $global:outputFile -Value "$dataArray";#Add content to the txt file
	}
	elseif($output -eq "csv")
	{
		$global:outputFile = "$currentDirectory\Reports\Tenant_Information_$($worksheetName)_$($dateTimeNow).csv";
		if(!$keeplogs.IsPresent)
		{
			$global:outputFile = "$currentDirectory\Reports\Tenant_Information_$($worksheetName).csv";
		}
		$dataArray -join "," | add-content -path $global:outputFile; #Add content to the CSV file
	}
	else{
		#$global:outputFile = "$currentDirectory\Reports\Tenant_Information_$($worksheetName)_$($dateTimeNow).xlsx";
		if($dataArray -ne $null)
		{			
			foreach($data in $dataArray)
			{
				$global:wksht.Cells.Item($global:rowNumber, $global:colNumber) = $data; #Write data to cell
				$global:wksht.Cells.Item($global:rowNumber, $global:colNumber).Font.Bold= $true; #Make cell bold
				if($colorIndex) #if a color number is provided, assign that color to that cell
				{
					try
					{
						$global:wksht.Cells.Item($global:rowNumber, $global:colNumber).Font.ColorIndex = $colorIndex;
					}
					catch{}
				}
				$global:colNumber++; #Move to next column
			}
			$global:colNumber = 1; #Move to first column
			$global:rowNumber++; #Move to next row
		}
	}
}
#Send generated report(s) to Druva. Will ask for confirmation from customer.
Function output.email($passedParams)
{
	Add-Type -AssemblyName PresentationFramework
	$confirmSendReport = [System.Windows.MessageBox]::Show('Your reeport is generated successfully. Would you like to send this report to Druva?','Send Report?','YesNo');
	
	switch  ($confirmSendReport) {
	  'Yes' { 
				if($cred -eq $null)
				{
					$cred = Get-Credential -UserName $admin -Message "Please provide your credentials."
				}
				$O365Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://ps.outlook.com/powershell -Credential $cred -Authentication Basic -AllowRedirection;
				
				Import-PSSession $O365Session -AllowClobber;
				
				$smtpClientAuth = (Get-TransportConfig | Select SmtpClientAuthenticationDisabled).SmtpClientAuthenticationDisabled;
				
				if($smtpClientAuth -eq $true)
				{
					$confirmSMTPClientAuth = [System.Windows.MessageBox]::Show('SMTP Client Authentication is disabled at your tenant. This needs to be enabled inorder to send email. Do you want to enable this?','SMTP Client Authentication?','YesNo');
					
					if($confirmSMTPClientAuth -eq "Yes")
					{
						Set-TransportConfig -SmtpClientAuthenticationDisabled:$false
					}
					else
					{
						log.error "No action taken. Report is not send to Druva.";
						exit;
					}
				}
				
				$from = "Customer Admin <$admin>";
				$to = "Druva Support <support@druva.com>";				
				$subject = "Tenant Profiler Report";
				$attachments = $null;				
				$smtp = "smtp.office365.com";
				$filter = "$dateTimeNow";
				#Write-Host $filter
				#Write-Host Get-ChildItem -Path ".\Reports\" -Filter "*_$filter.*";
				$attachments = Get-ChildItem -Path ".\Reports" -Filter "*_$filter.*" | Select -Expand FullName;
				
				if($attachments -ne $null)
				{
					$attachmentCount = $attachments.Count;
					$body = "<H1>Tenant Profiler Report is attached</H1><DIV>"+
								"<P><B>From:</B>$from</P>"+
								"<P><B>To:</B>$to</P>"+
								"<P><B>Total Report(s):</B>$attachmentCount</P>"+
								"<P><B>Arguments:</B>$($passedParams)</P>"+
							"</DIV>";
					log.info "Sending message...";
					Send-MailMessage -From $from -To $to -Subject $subject -Body $body -SmtpServer $smtp -Port 587 -Credential $cred -UseSsl -Attachments $attachments -BodyAsHtml -ErrorAction Stop;
					if($_.Error) #Error occured while connecting...
					{
						Write-Error "Error sending email. You can find report(s) in Reports folder and can send.";
						exit;
					}
					else
					{
						log.success "Email sent to '$from' successfully";
					}
				}
				else
				{
					log.error "No attachments found to send";
				}
	  }
	  'No' { log.error "Report is not send to Druva"  }
	}
}