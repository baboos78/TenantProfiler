#*************** DRUVA TENANT PROFILER 1.0 ************
#Author: 			Babu Pillai / babu.pillai@druva.com
#Last Modified On:	04/22/2022


Function users.load
{
	if($mfa.IsPresent) #Open authentication windows for MFA enabled environments
	{
		log.info "Connecting to MsOnline using modern authentication..."
		Connect-MsolService -ErrorAction Stop #Connect to Microsoft Online Service.This will open a window for user to enter credentials.
		if($_.Error) #Error occured while connecting...
		{
			log.error "Cannot connect to MsOnline";
			exit;
		}
		log.success "Connected to MsOnline";
		Write-Host "";
	}
	else
	{
		log.info "Connecting to MsOnline..."
		Connect-MsolService -Credential $global:cred -ErrorAction Stop;#Connect to MsOnline by passing credentials. Stop if errors out.
		if($_.Error) #Error occured while connecting
		{
			log.error "Cannot connect to MsOnline";
			exit;
		}
		log.success "Connected to MsOnline";
		Write-Host "";
	}
}

#Collects User Information
Function users.get
{
	module.check "MsOnline"; #Ensure Microsoft Online module is installed and improted.
	
	log.info "Getting User Information...";
	$global:users = Get-MsolUser -All | Select DisplayName,UserPrincipalName,IsLicensed,UsageLocation,BlockCredential,Country,ObjectId,CloudExchangeRecipientDisplayType,LicenseAssignmentDetails | Sort-Object DisplayName;
	log.info "Total Users: $($global:users.Count)";
	
	$global:userCount = ($global:users | Where {$_.IsLicensed -eq $true}).Count; #get user count	
	log.info "Total Licensed Users: $($global:userCount)";
	
	output.create $USER_RPRT_NAME @("DisplayName","UserPrincipalName","IsLicensed?","IsBlocked?","UsageLocation","Country","MFA?","Roles","MailboxType", "LicenseAssignmentDetails");
	foreach($user in $global:users)
	{
		log.success "`t$($user.UserPrincipalName)"
		
		$msolRoles = Get-MsolUserRole -ObjectId $user.ObjectId
		$roles = $msolRoles.Name -join ","
		
		$mfa = if( $user.StrongAuthenticationRequirements.State -ne $null){ $user.StrongAuthenticationRequirements.State} else { "Disabled"};
		$cldExchRecptDispType = GetCloudExchangeRecipientDisplayType $user.CloudExchangeRecipientDisplayType
		
		$licensesAssigned = "";
		if($user.LicenseAssignmentDetails)
		{
			foreach($licAssignDetail in $user.LicenseAssignmentDetails)
			{
				$licensesAssigned += "$($licAssignDetail.AccountSku.SkuPartNumber);";
			}
		}
		
		$data = $($user.DisplayName,$user.UserPrincipalName,$user.IsLicensed,$user.BlockCredential,$user.UsageLocation,$user.Country,$mfa,$roles,$cldExchRecptDispType,$licensesAssigned)
		
		if($user.IsLicensed)
		{
			$global:licensedUserCount++;
			if(!$user.BlockCredential)
			{
				$global:unblockLicensedUserCount++;
			}
		}
		if($user.BlockCredential)
		{
			$global:blockedUserCount++;
		}
		
		
		output.log $USER_RPRT_NAME $data; #Write User information to report
	}
	$global:users = $null;
}
function GetCloudExchangeRecipientDisplayType($typeId)
{
	if($typeId -eq $null){
		$typeId = -1;
	}
	$mailboxType = @{
		-1           = "NONE"
		0            = "SharedMailbox"
		1073741824   = "UserMailbox"
		6            = "ContactMailbox"
		7            = "RoomMailbox"
		8            = "EquipmentMailbox"
		-2147483642  = "RemoteUserMailbox"
		-1073741818  = "RemoteUserMailbox-Hybrid Delegate"		
	}
	try
	{
		return $mailboxType[$typeId];
	}
	catch{
		return "$typeId";
	}
}
Function GetCloudExchangeRecipientDisplayType123($typeId)
{
	$exchangeRecipientDisplayType = "UserMailbox";
	if($typeId -eq 0)
	{
		$exchangeRecipientDisplayType = "SharedMailbox";
	}
	elseif($typeId -eq 6)
	{
		$exchangeRecipientDisplayType = "ContactMailbox";
	}
	elseif($typeId -eq 7)
	{
		$exchangeRecipientDisplayType = "RoomMailbox";
	}
	elseif($typeId -eq 8)
	{
		$exchangeRecipientDisplayType = "EquipmentMailbox";
	}
	elseif($typeId -eq 1073741824)
	{
		$exchangeRecipientDisplayType = "UserMailbox";
	}
	return $exchangeRecipientDisplayType;
}
