#*************** DRUVA TENANT PROFILER 1.0 ************
#Author: 			Babu Pillai / babu.pillai@druva.com
#Last Modified On:	04/22/2022

#Get Microsoft 365 Groups information
Function groups.get
{  
	output.create $GRPS_RPRT_NAME @("Alias", "Name","DisplayName","AccessType","SharePointSiteUrl","GroupMemberCount","PrimarySmtpAddress","GroupType","Owner");
	$groups = $null;
	try
	{
		$groups = Get-UnifiedGroup -ResultSize Unlimited -ErrorAction SilentlyContinue | Select Alias,Name,DisplayName,AccessType,SharePointSiteUrl,GroupMemberCount,PrimarySmtpAddress,GroupType,ManagedBy | Sort-Object DisplayName;
	}
	catch
	{
		eo.load;
		$groups = Get-UnifiedGroup -ResultSize Unlimited -ErrorAction SilentlyContinue | Select Alias,Name,DisplayName,AccessType,SharePointSiteUrl,GroupMemberCount,PrimarySmtpAddress,GroupType,ManagedBy | Sort-Object DisplayName;
	}
	$global:groupsCount = $groups.Count;
	log.success "Found $($global:groupsCount) groups...";
	foreach($group in $groups)
	{
		log.success "`t$($displayName)"
		$alias = $group.Alias;
		$name = $group.Name;
		$displayName = $group.DisplayName;
		$accessType = $group.AccessType;
		$spUrl = $group.SharePointSiteUrl;
		$memberCount = $group.GroupMemberCount;
		$smtp = $group.PrimarySmtpAddress;		
		$type = $group.GroupType;
		$owner = $group.ManagedBy -join ',';
		
		output.log $GRPS_RPRT_NAME $($alias,$name,$displayName,$accessType,$spUrl,$memberCount,$smtp,$type,$owner);
	}
}