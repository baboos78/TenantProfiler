#*************** DRUVA TENANT PROFILER 1.0 ************
#Author: 			Babu Pillai / babu.pillai@druva.com
#Last Modified On:	04/22/2022

param (
	[switch]$show
	)
function form.load()
{
    $skus = @(50,100,250,500)
    $apps = @("EXCH","OD","SP","TEAMS","PF","GRP","POWERAPPS")
    $outputs = @("xls","txt","csv")

    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing

    $form = New-Object System.Windows.Forms.Form
    $form.Text = 'Collect Environment Information'
    $form.Size = New-Object System.Drawing.Size(800,800)
    $form.StartPosition = 'CenterScreen'

    [int]$x = 10;
    [int]$y = 25;
    [int]$ctrWidth = 400;
    [int]$ctrHeight = 30;
	
	[int]$inputCtrWidth = 300;
    [int]$inputCtrHeight = 30;

    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Location = New-Object System.Drawing.Point($x,$y)
    $lbl.Size = New-Object System.Drawing.Size($ctrWidth,$ctrHeight)
	$lbl.Font = [System.Drawing.Font]::new("Microsoft Sans Serif", 10, [System.Drawing.FontStyle]::Bold)
    $lbl.Text = 'Tenant Name (without .onmicrosoft.com)'
    $form.Controls.Add($lbl)

    $ctrlX = $ctrWidth+10;
    $tenantTxt = New-Object System.Windows.Forms.TextBox
    $tenantTxt.Location = New-Object System.Drawing.Point($ctrlX,$y)
    $tenantTxt.Size = New-Object System.Drawing.Size($inputCtrWidth,$ctrHeight)
	$tenantTxt.Font = [System.Drawing.Font]::new("Microsoft Sans Serif", 20, [System.Drawing.FontStyle]::Normal)
    $form.Controls.Add($tenantTxt)

    $y = $y + 40;
    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Location = New-Object System.Drawing.Point($x,$y)
    $lbl.Size = New-Object System.Drawing.Size($ctrWidth,$ctrHeight)
	$lbl.Font = [System.Drawing.Font]::new("Microsoft Sans Serif", 10, [System.Drawing.FontStyle]::Bold)
    $lbl.Text = 'Select sku you want to apply'
    $form.Controls.Add($lbl)

    $ctrlX = $ctrWidth+10;
    $skuTxt = New-Object System.Windows.Forms.ComboBox
    $skuTxt.Location = New-Object System.Drawing.Point($ctrlX,$y)
    $skuTxt.Size = New-Object System.Drawing.Size($inputCtrWidth,$ctrHeight)

    $skuTxt.Items.AddRange($skus)
    $skuTxt.SelectedIndex = 0;
    $form.Controls.Add($skuTxt)

    $y = $y + 40;
    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Location = New-Object System.Drawing.Point($x,$y)
    $lbl.Size = New-Object System.Drawing.Size($ctrWidth,$ctrHeight)
	$lbl.Font = [System.Drawing.Font]::new("Microsoft Sans Serif", 10, [System.Drawing.FontStyle]::Bold)
    $lbl.Text = 'Enter Global Admin Account'
    $form.Controls.Add($lbl)

    $ctrlX = $ctrWidth+10;
    $adminTxt = New-Object System.Windows.Forms.TextBox
    $adminTxt.Location = New-Object System.Drawing.Point($ctrlX,$y)
    $adminTxt.Size = New-Object System.Drawing.Size($inputCtrWidth,$ctrHeight)
    $form.Controls.Add($adminTxt)

    $y = $y + 40;
    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Location = New-Object System.Drawing.Point($x,$y)
    $lbl.Size = New-Object System.Drawing.Size($ctrWidth,$ctrHeight)
	$lbl.Font = [System.Drawing.Font]::new("Microsoft Sans Serif", 10, [System.Drawing.FontStyle]::Bold)
    $lbl.Text = 'Select Applications to Collect Data'
    $form.Controls.Add($lbl)

    $ctrlX = $ctrWidth+10;
    $appTxt = New-Object System.Windows.Forms.CheckedListBox
    $appTxt.Location = New-Object System.Drawing.Point($ctrlX,$y)
    $appTxt.Size = New-Object System.Drawing.Size($inputCtrWidth,80)
    $appTxt.Items.AddRange($apps)
    #$appTxt.SelectedIndex = 0
	for ($i = 0; $i -lt $appTxt.Items.Count; $i++)
	{
		$appTxt.SetItemChecked($i, $true);
	}
    $form.Controls.Add($appTxt)

    $y = $y + 100;
    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Location = New-Object System.Drawing.Point($x,$y)
    $lbl.Size = New-Object System.Drawing.Size($ctrWidth,$ctrHeight)
	$lbl.Font = [System.Drawing.Font]::new("Microsoft Sans Serif", 10, [System.Drawing.FontStyle]::Bold)
    $lbl.Text = 'Select desired output required'
    $form.Controls.Add($lbl)

    $ctrlX = $ctrWidth+10;
    $outputTxt = New-Object System.Windows.Forms.ComboBox
    $outputTxt.Location = New-Object System.Drawing.Point($ctrlX,$y)
    $outputTxt.Size = New-Object System.Drawing.Size($inputCtrWidth,$ctrHeight)

    $outputTxt.Items.AddRange($outputs);
    $outputTxt.SelectedIndex = 0;
    $form.Controls.Add($outputTxt)

    $y = $y + 40;
	[int]$ctlH = $ctrHeight+30;
    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Location = New-Object System.Drawing.Point($x,$y)
    $lbl.Size = New-Object System.Drawing.Size($ctrWidth,$ctlH)
	$lbl.Font = [System.Drawing.Font]::new("Microsoft Sans Serif", 10, [System.Drawing.FontStyle]::Bold)
    $lbl.Text = 'Is MFA/Conditional Access Turned On? (Multiple credential entries needed)'
    $form.Controls.Add($lbl)

    $ctrlX = $ctrWidth+10;
    $mfaChk = New-Object System.Windows.Forms.Checkbox
    $mfaChk.Location = New-Object System.Drawing.Point($ctrlX,$y)
    $mfaChk.Size = New-Object System.Drawing.Size($inputCtrWidth,$ctrHeight)
    $form.Controls.Add($mfaChk)

    $y = $y + 60;
    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Location = New-Object System.Drawing.Point($x,$y)
    $lbl.Size = New-Object System.Drawing.Size($ctrWidth,$ctrHeight)
	$lbl.Font = [System.Drawing.Font]::new("Microsoft Sans Serif", 10, [System.Drawing.FontStyle]::Bold)
    $lbl.Text = 'Do you want to keep old logs/results?'
    $form.Controls.Add($lbl)

    $ctrlX = $ctrWidth+10;
    $keepLogsChk = New-Object System.Windows.Forms.Checkbox
    $keepLogsChk.Location = New-Object System.Drawing.Point($ctrlX,$y)
    $keepLogsChk.Size = New-Object System.Drawing.Size($inputCtrWidth,$ctrHeight)
    $form.Controls.Add($keepLogsChk)

    $y = $y + 40;
    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Location = New-Object System.Drawing.Point($x,$y)
    $lbl.Size = New-Object System.Drawing.Size($ctrWidth,$ctrHeight)
	$lbl.Font = [System.Drawing.Font]::new("Microsoft Sans Serif", 10, [System.Drawing.FontStyle]::Bold)
    $lbl.Text = 'Send Report to Druva automatically? (You can always find report in "Reports" folder and send later)'
    $form.Controls.Add($lbl)

    $ctrlX = $ctrWidth+10;
    $emailChk = New-Object System.Windows.Forms.Checkbox
    $emailChk.Location = New-Object System.Drawing.Point($ctrlX,$y)
    $emailChk.Size = New-Object System.Drawing.Size($inputCtrWidth,$ctrHeight)
    $form.Controls.Add($emailChk)
	
	$y = $y + 40;
	$bannerWidth = $ctrWidth + 300;
    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Location = New-Object System.Drawing.Point($x,$y)
    $lbl.Size = New-Object System.Drawing.Size($bannerWidth,$ctrHeight)
	$lbl.Font = [System.Drawing.Font]::new("Microsoft Sans Serif", 15, [System.Drawing.FontStyle]::Italic)
	$lbl.BackColor = "Lime";
    $lbl.Text = '=== FOR SHAREPOINT and ONEDRIVE ONLY ==='
    $form.Controls.Add($lbl)

    $y = $y + 40;
    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Location = New-Object System.Drawing.Point($x,$y)
    $lbl.Size = New-Object System.Drawing.Size($ctrWidth,$ctrHeight)
	$lbl.Font = [System.Drawing.Font]::new("Microsoft Sans Serif", 10, [System.Drawing.FontStyle]::Bold)
    $lbl.Text = 'Need full site details? (This takes longer time to run)'
    $form.Controls.Add($lbl)

    $ctrlX = $ctrWidth+10;
    $detailedlChk = New-Object System.Windows.Forms.Checkbox
    $detailedlChk.Location = New-Object System.Drawing.Point($ctrlX,$y)
    $detailedlChk.Size = New-Object System.Drawing.Size($inputCtrWidth,$ctrHeight)
    $form.Controls.Add($detailedlChk)
	
	$y = $y + 40;
    $phlLbl = New-Object System.Windows.Forms.Label
    $phlLbl.Location = New-Object System.Drawing.Point($x,$y)
    $phlLbl.Size = New-Object System.Drawing.Size($ctrWidth,$ctrHeight)
	$phlLbl.Font = [System.Drawing.Font]::new("Microsoft Sans Serif", 10, [System.Drawing.FontStyle]::Bold)
    $phlLbl.Text = 'Get Preservation Hold Library Information?'	
    $form.Controls.Add($phlLbl)

    $ctrlX = $ctrWidth+10;
    $phlChk = New-Object System.Windows.Forms.Checkbox
    $phlChk.Location = New-Object System.Drawing.Point($ctrlX,$y)
    $phlChk.Size = New-Object System.Drawing.Size($inputCtrWidth,$ctrHeight)	
    $form.Controls.Add($phlChk)

    $x = $x + 40;
    $y = $y + 100;
    #Okay button
    $okButton = New-Object System.Windows.Forms.Button
    $okButton.Location = New-Object System.Drawing.Point($x,$y)
    $okButton.Size = New-Object System.Drawing.Size(75,23)
    $okButton.Text = 'OK'
    $okButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $form.AcceptButton = $okButton
    $form.Controls.Add($okButton)

    $ctrlX = $x+100;
    #Cancel button
    $cancelButton = New-Object System.Windows.Forms.Button
    $cancelButton.Location = New-Object System.Drawing.Point($ctrlX,$y)
    $cancelButton.Size = New-Object System.Drawing.Size(75,23)
    $cancelButton.Text = 'Cancel'
    $cancelButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $form.CancelButton = $cancelButton
    $form.Controls.Add($cancelButton)

    #hide preservation library info if detailed is checked
	
	$detailedlChk.Add_CheckStateChanged(
	{
		if($detailedlChk.Checked)
		{
			$phlLbl.Visible = $false;
			$phlChk.Visible = $false;
			$phlChk.Checked = $false;
		}
		else
		{
			$phlLbl.Visible = $true;
			$phlChk.Visible = $true;
		}
	});
	

    $form.Topmost = $true;
    $form.Add_Shown({$tenantTxt.Select()})

    $result = $form.ShowDialog();

    if ($result -eq [System.Windows.Forms.DialogResult]::OK)
    {
        $tenant = $tenantTxt.Text
        $sku = $skuTxt.SelectedItem;
        $admin = $adminTxt.Text;
	    $app = $appTxt.CheckedItems -join "#"
        $output = $outputTxt.SelectedItem
        $mfa = $mfaChk.Checked
        $keeplogs = $keepLogsChk.Checked
        $email = $emailChk.Checked
        $detailed = $detailedlChk.Checked
		$libTitle = "";
		if($phlChk.Checked)
		{
			$libTitle = "Preserrvation Hold Library";
		}
		
		$global:form_tenant = $tenantTxt.Text
		$global:form_sku = $skuTxt.SelectedItem
		$global:form_top = 
		$global:form_detailed = $detailedlChk.Checked
		$global:form_debug = false
		$global:form_admin = $adminTxt.Text
		$global:form_app  = $appTxt.CheckedItems -join "#"
		$global:form_output = $outputTxt.SelectedItem
		$global:form_mfa = $mfaChk.Checked
		$global:form_keeplogs = $keepLogsChk.Checked
		$global:form_email = $emailChk.Checked	    
		$global:libTitle = $libTitle
    }
}

if($show.IsPresent)
{
	form.load
}
