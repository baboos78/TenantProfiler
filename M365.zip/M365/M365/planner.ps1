
#Planner information

function planner.get()
{
	module.check("Microsoft.Graph.Planner")
	
	Connect-MgGraph
}
