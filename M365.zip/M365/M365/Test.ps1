#Enter-PSSession -ComputerName $env:computername
$currentDirectory =  (Get-Location).Path;
$spclientDLL = "$currentDirectory\ScanSites\Microsoft.SharePoint.Client.dll"
$spclienRunTimetDLL = "$currentDirectory\ScanSites\Microsoft.SharePoint.Client.Runtime.dll"
$officeDevtDLL = "$currentDirectory\ScanSites\OfficeDevPnP.Core.dll"
$scanSitesDll = "$currentDirectory\ScanSites\ScanSites.dll"

$loadedAssemblies = [System.AppDomain]::CurrentDomain.GetAssemblies();

if(($loadedAssemblies | Where {$_ -match "Microsoft.SharePoint.Client"}) -eq $null )
{	
	[Reflection.Assembly]::LoadFile($spclientDLL);
}
if(($loadedAssemblies | Where {$_ -match "Microsoft.SharePoint.Client.Runtime"}) -eq $null)
{	
	[Reflection.Assembly]::LoadFile($spclienRunTimetDLL);
}
if(($loadedAssemblies | Where {$_ -match "OfficeDevPnP.Core"}) -eq $null)
{
	[Reflection.Assembly]::LoadFile($officeDevtDLL);
}
if(($loadedAssemblies | Where {$_ -match "ScanSites"}) -eq $null)
{
	[Reflection.Assembly]::LoadFile($scanSitesDll);
	$classInfo = $scanSitesDll.GetType("Druva.Services.SharePoint.Program");
}

$siteUrl = "https://365druva.sharepoint.com/sites/retainforever";
$libTitle = "Preservation Hold Library"
$siteInfo = [Druva.Services.SharePoint.Program]::Get($siteUrl,$libTitle)
if($siteInfo -ne $null)
{
	Write-Host "Found site info" -f Green
	$siteInfo
	$libSize = 0;
	$libItemCount = 0;
	$recycleBinSize = 0;
	$recycleBinItemCount = 0;
	foreach ($webs in $siteInfo.SPOWebs)
	{
		foreach($web in $webs)
		{
			$types = "";
			foreach($list in $web.Lists)
			{
				$libSize += $list.SizeInBytes;
				$libItemCount += $list.FileCount;
			}
			$recycleBinSize += $web.RecycleBinSize;
			$recycleBinItemCount += $web.RecycleBinItemCount;
			Write-Host $web.Title `t $web.Url `t $web.RecycleBinItemCount `t $web.RecycleBinSize `t $libSize`t $libItemCount
		}
	}
	Write-Host $siteInfo.siteTitle `t $siteInfo.siteUrl `t $recycleBinItemCount `t $recycleBinSize `t $libSize`t $libItemCount
}
#Exit-PSSession
