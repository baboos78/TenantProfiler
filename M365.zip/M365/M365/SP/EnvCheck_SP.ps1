param (
	[string]$tenant = "",
	[string]$admin = "",
	[string]$siteurl = ""
	);
$global:iCount = 0;
if($tenant -eq "")
{
	Write-Error "Tenant name is missing."
	exit;
}


function appendToOutput($spSite)
{	
	
	$spSite | Select Title,Url,StorageUsageCurrent,Template, Status, LastContentModifiedDate | Export-Csv -Append -Path $outfile
}
function getSiteInfo($spoSite)
{
	Write-Host $spoSite.Url
	if(($spoSite.LockState -ne "ReadOnly") -AND ($admin -ne ""))
	{
		try
		{
			try
			{
				Set-SPOUser -Site $spoSite -LoginName $admin -IsSiteCollectionAdmin $true #add user as Site collection admin
			}
			catch
			{
				Write-Host "Error adding admin" -f Red;
				Write-Host $_ -f Red
			}
			appendToOutput($spoSite);
			try
			{
				Set-SPOUser -Site $spoSite -LoginName $admin -IsSiteCollectionAdmin $false #remove user as Site collection admin
			}
			catch
			{
				Write-Host "Error removing admin" -f Red;
				Write-Host $_ -f Red
			}
		}
		catch
		{
			Write-Host "Error in getting site info"
			Write-Host $_ -f Red
		}
	}
	else
	{
		appendToOutput($spoSite);
	}
	
}

$dateTimeNow = Get-Date -Format "MM-dd-yyyy_hh_mm";
$outfile = ".\Outfile_$($dateTimeNow).csv";
$newcsv = {} | Select "Title","Url","StorageUsageCurrent","Template","Status","LastContentModifiedDate" | Export-Csv $outfile;

Connect-SPOService -Url https://$tenant-admin.sharepoint.com;

if($siteurl -eq "")
{
	Write-Host "Getting SP site list...";
	$spoSites = Get-SPOSite -IncludePersonalSite:$false -Limit All -Detailed ;
	Write-Host "Found $($spoSites.Count) sites. Starting analysis...";
	foreach($spoSite in $spoSites)
	{		
		getSiteInfo($spoSite);
	}
}
else
{
	$spoSite = Get-SPOSite -Identity $siteurl -Detailed ;
	getSiteInfo($spoSite);
}