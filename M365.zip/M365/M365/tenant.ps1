#*************** DRUVA TENANT PROFILER 1.0 ************
#Author: 			Babu Pillai / babu.pillai@druva.com
#Last Modified On:	04/22/2022

Function tenant.load
{
	module.check "AzureAD"; #Ensure Azure AD module is installed and improted.
	
	if($mfa.IsPresent) #Open authentication windows for MFA enabled environments
	{
		log.info "Connecting to Azure AD using modern authentication...."
		Connect-AzureAD -ErrorAction Stop #Connect to Azure AD. This will open a window for user to enter credentials.
		if($_.Error) #Error occured while connecting...
		{
			log.error "Cannot connect to Azure Active Directory";
			exit;
		}
		log.success "Connected to Azure AD";		
	}
	else
	{
		log.info "Connecting to Azure AD....";
		Connect-AzureAD	-Credential $global:cred -ErrorAction Stop; #Connect to Azure AD by passing credentials. Stop if errors out.
		if($_.Error) #Error occured while connecting...
		{
			log.error "Cannot connect to Azure Active Directory";
			exit;
		}
		log.success "Connected to Azure AD";		
	}
}
#Check custome Microsoft 365 environment for
	#Licenses
	#If multi-geo environment, get list of geo locations
Function tenant.get
{
	output.create $LICENSE_RPRT_NAME @("AccountSkuId","ActiveUnits","ConsumedUnits");
	$accountSkus = Get-MsolAccountSku #Get all license count
	foreach($accountSku in $accountSkus)
	{
		$data = $($accountSku.AccountSkuId,$accountSku.ActiveUnits,$accountSku.ConsumedUnits)
		output.log $LICENSE_RPRT_NAME $data; #Write License information to report
	}
				
	$tenantInfo =  Get-AzureADTenantDetail -All $true; #get tenant information
	$geoLocations = Get-MsolCompanyAllowedDataLocation -TenantId $tenantInfo.ObjectId | Sort-Object Location #get geo locations
		
	if($geoLocations -ne $null) #Multi-Geo is enabled in customer tenant
	{		
		output.create $MULTIGEO_RPRT_NAME @("Location", "ServiceType");		
		foreach($geoLocation in $geoLocations)
		{
			output.log $MULTIGEO_RPRT_NAME $($geoLocation.Location, $geoLocation.ServiceType); #Write to report
		}
	}	
}