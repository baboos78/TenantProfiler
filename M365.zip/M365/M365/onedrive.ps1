#*************** DRUVA TENANT PROFILER 1.0 ************
#Author: 			Babu Pillai / babu.pillai@druva.com
#Last Modified On:	04/22/2022

#Get OneDrive information from customer tenant
Function od.get
{
	log.success "Loading OneDrive information...";
	if($detailed.IsPresent) #Generate detailed OneDrive report
	{
		output.create $OD_RPRT_NAME @("Title","Template","URL","Total Folders","Total Items","Total Files", "Size (MB)","Status", "RecycleBinCount","RecycleBinSize","Last Modified On","List Types","Owner","Error");
	}
	else
	{
		#Generate normal OneDrive report
		output.create $OD_RPRT_NAME @("Title","Template","URL", "Size (MB)","Status", "Last Modified On","Owner");
	}
	$mySitePrefix = "https://$tenant-my.sharepoint.com"; #OneDrive URL for customer
	if($top -eq 0)#no top number is provided, get all OneDrive info
	{
		$odSites = Get-SPOSite -IncludePersonalSite:$true -Limit All -Detailed -Filter {Url -like '-my.sharepoint.com'} | Sort-Object Title;
	}
	else # Only top OneDrive info will be reviewed.
	{
		$odSites = Get-SPOSite -IncludePersonalSite:$true -Limit $top -Detailed -Filter {Url -like '-my.sharepoint.com'} | Sort-Object Title;
	}
	$global:odCount = $odSites.Count; # OneDrive sites collected
	if($debug.isPresent)
	{ 
		log.info "Found $global:odCount Sites"
		log.info "admin: $admin"
	}
	foreach($odSite in $odSites) #Loop through OneDrive Collection
	{
		log.success "`t$($odSite.URL)"
		try 
		{
			if ($force.IsPresent) #Add account as SCA if force is present
			{
				$admin = Set-SPOUser -Site $odSite.URL -LoginName $admin -IsSiteCollectionAdmin $true #add user as Site collection admin
				
				sharepoint.getsitedetails $odSite $OD_RPRT_NAME; #Collect OneDrive information
				try{
					#Remove SCA role for account
					$removeAdmin = Set-SPOUser -Site $odSite -LoginName $admin -IsSiteCollectionAdmin $false #remove user as Site collection admin
				}
				catch
				{
					log.error $_
				}
			}
			else
			{
				if(($odSite.LockState -eq "ReadOnly") -AND ($detailed.IsPresent))
				{
					log.error "OneDrive is readonly"
					output.log $OD_RPRT_NAME $($odSite.Title,$odSite.Template,$odSite.URL,-1,-1,-1,$odSite.StorageUsageCurrent,$odSite.Status,-1,-1, $odSite.LastContentModifiedDate,$odSite.Owner,"OneDrive is readonly");
				}
				else
				{
					sharepoint.getsitedetails $odSite $OD_RPRT_NAME; #Collect SPO details
				}				
			}
		}
		catch
		{
			log.error $_ -f Magenta
		}		
	}
	if($detailed.IsPresent) #Get detailed fields and list information for OneDrive
	{
		sharepoint.getlists $OD_LISTS_RPRT_NAME $OD_FIELDS_RPRT_NAME #Load list information
	}
}