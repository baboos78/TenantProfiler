#*************** DRUVA TENANT PROFILER 1.0 ************
#Author: 			Babu Pillai / babu.pillai@druva.com
#Last Modified On:	04/22/2022

Function teams.load
{
	module.check "MicrosoftTeams"
		
	log.info "Connecting to Microsoft Teams..."; #Prompt user to enter credentials to connect to Teams environment.
	if($mfa.IsPresent)
	{
		Connect-MicrosoftTeams 
	}
	else
	{
		Connect-MicrosoftTeams -Credential $global:cred; #Connect to Teams environment with credentials
	}
	if($_.Error)
	{
		log.error "Cannot connect to Microsoft Teams";
		exit;
	}
	log.success "Connected to Microsoft Teams";
	Write-Host "";
}

#Collect Microsoft Teams information in the tenant
#This process uses MicrosoftTeams cmdlets for data collection
Function teams.get
{	
	output.create $TEAMS_RPRT_NAME @("Team Name","Visibility","Total Users","Total Channels","Total Private Channels", "Users","Channels");
	$teams = $null;
	try
	{
		$teams = Get-Team -ErrorAction Stop | Sort-Object DisplayName;
	}
	catch
	{
		teams.load
	}
	 #Get all Teams in Customer Tenant
	$global:teamCount = $teams.Count;
	
	log.info "Found $global:teamCount Team Sites";
	$iCount = 0;
	foreach($team in $teams) #Loop through the list of teams
	{
		$teamName = $team.DisplayName;
		$visibility = $team.Visibility;
		
		log.success "`t$teamName"
		
		$userList = "";
		$users = Get-TeamUser -GroupId $team.GroupId;		
		foreach($user in $users) #Get users information
		{
			$userList += $user.Name + "(" + $user.Role + "); ";			
		}
		
		$channelList = "";
		$channels = Get-TeamChannel -GroupId $team.GroupId;	#Get Channel collections
		$privateChannelCount = 0;
		foreach($channel in $channels) #Loop through the channel collection
		{
			$channelList += $channel.DisplayName + "(" + $channel.MembershipType + "); ";
			
			if($channel.MembershipType -eq "Private")
			{
				$privateChannelCount++;
			}
		}	
		#Write to report
		output.log $TEAMS_RPRT_NAME $($teamName,$visibility,$users.Count, $channels.Count,$privateChannelCount, $userList,$channelList);
		
		$iCount++;
	}
}