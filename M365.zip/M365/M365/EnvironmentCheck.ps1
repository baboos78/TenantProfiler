#*************** DRUVA TENANT PROFILER 1.0 ************
#Author: 			Babu Pillai / babu.pillai@druva.com
#Last Modified On:	04/08/2022

param (
	[string]$tenant, #Tenant name without .onmicrosoft.com
	[int]$sku = 50, #Default size in GB per user license
	[int]$top = 0, #Only show top certain data. Can be used for POC tests	
	[string]$admin = "", #pass administrator UPN (only works with non-mfa environments
	[string]$password = "", #pass administrator password (only works with non-mfa environments
	[string]$app = "All", #Allows to run for selected app or all apps. 
	[string]$output = "xls", #returns output in multiple formats (xls,txt,csv)
	[string]$siteUrl = "", #GetDetails of a specific site. Works only for 
	[string]$libTitle = "", #GetDetails of a specific library
	[switch]$debug, #run in debug mode
	[switch]$mfa, #Specify to switch to modern authentication to get user input
	[switch]$help, #Run help mode to show parameters and values. Do not execute anything
	[switch]$keeplogs, #Keeping the previous logs in Reports folder
	[switch]$force, #Do some forceful activities like adding account to SharePoint site collections to collec detailed information
	[switch]$email #send report to customer
);
$global:workbook = $null; #clear workbook object if available

#Load associated powershell scripts
. .\log.ps1
. .\form.ps1
. .\output.ps1
. .\tenant.ps1
. .\users.ps1
. .\exchange.ps1
. .\public-folders.ps1
. .\groups.ps1
. .\sharepoint.ps1
. .\onedrive.ps1
. .\teams.ps1
. .\powerapps.ps1

#Setting execution policy to Bypass
Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Force -Scope CurrentUser -ErrorAction SilentlyContinue

#Set report names
$USER_RPRT_NAME = "Users";
$EXCH_RPRT_NAME = "Mailboxes";
$PF_RPRT_NAME = "Public Folder";
$OD_RPRT_NAME = "OneDrive";
$OD_INFO_RPRT_NAME = "OneDrive Info";
$OD_LISTS_RPRT_NAME = "OneDrive Lists";
$OD_FIELDS_RPRT_NAME = "OneDrive Fields";
$SP_RPRT_NAME = "SharePoint";
$SP_INFO_RPRT_NAME = "SharePoint Info";
$SP_LISTS_RPRT_NAME = "SharePoint Lists";
$SP_FIELDS_RPRT_NAME = "SharePoint Fields";
$TEAMS_RPRT_NAME = "Teams";
$SUMMARY_RPRT_NAME = "Summary";
$LICENSE_RPRT_NAME = "Licenses";
$MULTIGEO_RPRT_NAME = "Multi-Geo";
$GRPS_RPRT_NAME = "M365 Groups";
$PWRAPPS_RPRT_NAME = "Power Apps"

#Create valiable to store sitedetails information
$global:SiteDetails = New-Object System.Collections.Generic.List[object];

#Run in help mode.
Function help.show
{
	Write-Host "See help information";
	Write-Host "`t./EnvironmentCheck.ps1 -help" -f Magenta;
	
	Write-Host "Use below format to extract data. Tenant name should not contain '.onmicrosoft.com'";
	Write-Host "`t./EnvironmentCheck.ps1 -tenant [TENANT-NAME]" -f Magenta;
	
	Write-Host "To get data for a specfic app, use below format";
	Write-Host "`t./EnvironmentCheck.ps1 -tenant [TENANT-NAME] -app [All | EXCH | OD | SP | TEAMS | PF | GRP]" -f Magenta;
	
	Write-Host "To get data from multiple apps, use '#' to separate apps";
	Write-Host "`t./EnvironmentCheck.ps1 -tenant [TENANT-NAME] -app SP#OD" -f Magenta;
	
	Write-Host "Use -output parameter if you want data to be output to a text file. xls is the default";
	Write-Host "`t./EnvironmentCheck.ps1 -tenant [TENANT-NAME] -output txt" -f Magenta;
	
	Write-Host "For MFA enabled connections, use mfa switch. This will open multiple authentication windows";
	Write-Host "`t./EnvironmentCheck.ps1 -tenant [TENANT-NAME] -mfa" -f Magenta;
	
	Write-Host "Get more details of site collections like folder count, file count etc";
	Write-Host "`t./EnvironmentCheck.ps1 -tenant [TENANT-NAME] -detailed" -f Magenta;
}

if($help.IsPresent) #Show help window if -help command is used. Exit after that;
{
	help.show;
	exit;
}

if($tenant -eq "") #Show form if tenant name is provided. Parameters will be collected in the form.
{
	form.load;
	$tenant = $global:form_tenant
	$sku = $global:form_sku
	$top = $global:form_top
	$detailed = $global:form_detailed
	$admin = $global:form_admin
	$password = ""
	$app = $global:form_app 
	$output = $global:form_output
	if($global:form_mfa -ne $true)
	{
		$mfa = $null;
	}
	if($global:form_keeplogs -ne $true)
	{
		$keeplogs = $null;
	}
	if($global:form_email -ne $true)
	{
		$email = $null;
	}
	$libTitle = $global:libTitle
	
	Write-Host "************* Below is your selections *************"
	Write-Host "Tenant:`t$tenant"
	Write-Host "SKU:`t$sku"
	Write-Host "Admin:`t$admin"
	Write-Host "Apps:`t$app"
	Write-Host "Output:`t$output"
	Write-Host "MFA:`t$mfa"
	Write-Host "Keep old logs:`t$keeplogs"
	Write-Host "Email:`t$email"
	Write-Host "Detailed:`t$detailed"
	Write-Host "Library Title:`t$libTitle"
		
}
if($tenant -eq "") #Show error if tenant name is provided. This needs to be provided as a parameter
{
	Write-Error -Message "Tenant name cannot be empty" -Category InvalidData;
	help.show;
	exit;
}

#Ensure modules are installed properly in the environment
Function system.check
{
	Get-PSSession | Remove-PSSession #remove previous sessions
		
	if(!$mfa.IsPresent) #if environment is non-mfa enabled, we will collect user credentials and use it to authenticate to environments
	{
		if($password -ne "") #if password is provided in the parameter
		{
			$password = ConvertTo-SecureString $password -AsPlainText -Force; #Convert plain text password to secure string
			$global:cred = New-Object System.Management.Automation.PSCredential ($admin, $password); #Create credentials
		}
		else
		{
			#if password is empty, pop-up the autneitcation window for user to enter credentials
			$global:cred = Get-Credential -UserName $admin -Message "Please provide your global administrator credentials.";
		}
		
		if(!$global:cred) #Credentials are empty
		{
			log.error "Need credentials to continue...";
			exit;
		}
	}
	
	if(@("All","TENANT").Contains($app))
	{
		tenant.load;
	}
		
	if(@("All","USERS").Contains($app))
	{
		users.load;
	}
	
	if(@("All","EXCH","PF","GRP").Contains($app) -OR ($app.Contains("#") -AND $app.Split("#").Contains("EXCH") -AND $app.Split("#").Contains("GRP")))
	{
		eo.load;
	}
	
	if(@("All","SP","OD").Contains($app) -OR ($app.Contains("#") -AND ($app.Split("#").Contains("SP") -OR $app.Split("#").Contains("OD")))) #For SharePoint and OneDrive scans
	{
		sharepoint.load;
	}
	
	if(@("All","TEAMS").Contains($app) -OR ($app.Contains("#") -AND $app.Split("#").Contains("TEAMS"))) #For Microsoft Teamsscans
	{
		teams.load;
	}
	
	if(@("All","POWERAPPS").Contains($app) -OR ($app.Contains("#") -AND $app.Split("#").Contains("POWERAPPS"))) #For Microsoft Power app scans
	{
		powerapps.load;
	}
}

#Check if modules are installed in the environment
Function module.check($name)
{
	if((Get-Module -Name $name) -ne $null) #Module is found in the environment
	{
		log.success "Successfully validated $name"
		Import-Module -Name $name; #Module is imported to environment
		return;
	}
	if($force.IsPresent) #Force uninstall the module
	{
		UnInstall-Module -Name $name -Force
	}
	log.info "$name module not found. Trying to install..."
	try 
	{
		#Install module to environment
		Install-Module -Name $name -Force -Confirm:$false -SkipPublisherCheck -Scope CurrentUser -AllowClobber;
		#Import module to session
		Import-Module -Name $name -DisableNameChecking -Force
		
		log.success "Successfully installed and imported $name";		
	}
	catch
	{
		log.error "$name install/import failed.";
		exit;
	}
}

#Generate summary report based on the data collected.
Function summary.load
{
	output.create $SUMMARY_RPRT_NAME @("Environment Information");
	output.log $SUMMARY_RPRT_NAME $("");
	$iCount = 0;
	if(@("All","EXCH").Contains($app)) #For Exchange and all app selection
	{
		output.logAsBold $SUMMARY_RPRT_NAME "Exchange"	
			output.log $SUMMARY_RPRT_NAME $("", "Total Mailboxes", $global:exchCount);
			$iCount++;	
			output.log $SUMMARY_RPRT_NAME $("", "Total Size(MB)", [math]::Round($global:exchSize,2));
			output.log $SUMMARY_RPRT_NAME $("", "Total Archived Mailboxes", $global:archiveExchCount);
			$iCount++;	
			output.log $SUMMARY_RPRT_NAME $("", "Total Archived Size(MB)", [math]::Round($global:archiveExchSize,2));
			$iCount++;
			$iCount++;
	}
	if(@("All","PF").Contains($app)) #For Public Folder and all app selection
	{
		output.logAsBold $SUMMARY_RPRT_NAME "Public Folder"
			output.log $SUMMARY_RPRT_NAME $("", "Count", $global:pfCount);
			$iCount++;	
			output.log $SUMMARY_RPRT_NAME $("", "Size (MB)", [math]::Round($global:pfSize,2));
			$iCount++;
			$iCount++;
	}
	if(@("All","OD").Contains($app))#For OneDrive and all app selection
	{
		output.logAsBold $SUMMARY_RPRT_NAME "OneDrive Info"
			output.log $SUMMARY_RPRT_NAME $("", "Count", $global:odCount);
			$iCount++;	
			output.log $SUMMARY_RPRT_NAME $("", "Size(MB)", [math]::Round($global:odSize,2));
			$iCount++;	
			$iCount++;
	}
	if(@("All","SP").Contains($app))#For SharePOint and all app selection
	{
		output.logAsBold $SUMMARY_RPRT_NAME "SharePoint Info"
			output.log $SUMMARY_RPRT_NAME $("", "Site Count ", $global:spCount);
			$iCount++;	
			output.log $SUMMARY_RPRT_NAME $("", "Size(MB)", [math]::Round($global:spSize,2));
			$iCount++;	
			$iCount++;
	}
	if(@("All","GRP").Contains($app)) #For Teams and all app selection
	{
		output.logAsBold $SUMMARY_RPRT_NAME "Microsoft 365 Groups"	
			output.log $SUMMARY_RPRT_NAME $("", "Count", $global:groupsCount);
			$iCount++;
			$iCount++;
	}
	if(@("All","TEAMS").Contains($app)) #For Teams and all app selection
	{
		output.logAsBold $SUMMARY_RPRT_NAME "Microsoft Teams"	
			output.log $SUMMARY_RPRT_NAME $("", "Count", $global:teamCount);
			$iCount++;
			$iCount++;
	}
	if(@("All","POWERAPPS").Contains($app)) #For Teams and all app selection
	{
		output.logAsBold $SUMMARY_RPRT_NAME "Power Apps"	
			output.log $SUMMARY_RPRT_NAME $("", "Environments", $global:paEnvCount);
			output.log $SUMMARY_RPRT_NAME $("", "Flows", $global:paFlowCount);
			output.log $SUMMARY_RPRT_NAME $("", "Apps", $global:paAppCount);
			$iCount++;
			$iCount++;
	}
	if(@("All").Contains($app)) #For all app selection
	{
		$existingSizeInMB = [math]::Round($($global:exchSize + $global:pfSize + $global:spSize + $global:odSize),2);
		output.log $SUMMARY_RPRT_NAME $("Total Size (MB)", $existingSizeInMB);
		$iCount++;
		
		$existingSizeInGB = [math]::Round($existingSizeInMB/1024,2);	
		output.logAsBold $SUMMARY_RPRT_NAME $("Total Size(GB):", [math]::Round($existingSizeInGB,2));
		$iCount++;
	}
	output.logAsBold $SUMMARY_RPRT_NAME $("Total Users in Organization:", $global:userCount);
	$iCount++;	
	$iCount++;
	output.logAsBold $SUMMARY_RPRT_NAME $("Total Licensed Users in Organization:", $global:licensedUserCount);
	$iCount++;	
	$iCount++;
	output.logAsBold $SUMMARY_RPRT_NAME $("Total Signin Blocked Users in Organization:", $global:blockedUserCount);
	$iCount++;	
	$iCount++;
	output.logAsBold $SUMMARY_RPRT_NAME $("Total Licensed & Signin Allowed Users in Organization:", $global:unblockLicensedUserCount);
	$iCount++;	
	$iCount++;
	
	$requiredSizeInGB = $($global:userCount * $sku);
	
	if($requiredSizeInGB -le $existingSizeInGB)
	{
		output.logAsBold $SUMMARY_RPRT_NAME $("Required Size (GB) (Total Users X SKU) = $($global:userCount) * $($sku) (GB):", $requiredSizeInGB) 3;
	}
	else
	{
		output.logAsBold $SUMMARY_RPRT_NAME $("Required Size (GB) (Total Users X SKU) = $($global:userCount)* $($sku) (GB):", $requiredSizeInGB) 5 ;
	}
	
}
#Process applications
Function app.process($appToProcess)
{	
	if($appToProcess -eq $null)
	{
		if(($app -eq "All") -or ($app -eq "TENANT"))
		{
			tenant.get; #Collect Exchange Information
		}
		if(($app -eq "All") -or ($app -eq "USERS"))
		{
			users.get; #Collect Teams Information
		}
		if(($app -eq "All") -or ($app -eq "EXCH"))
		{
			eo.get; #Collect Exchange Information
		} 
		if(($app -eq "All") -or ($app -eq "PF"))
		{
			pf.get; #Collect Public Folder Information
		}
		if(($app -eq "All") -or ($app -eq "OD"))
		{
			od.get; #Collect OneDrive Information
		}
		if(($app -eq "All") -or ($app -eq "SP"))
		{
			sharepoint.get; #Collect SharePoint Information
		}
		if(($app -eq "All") -or ($app -eq "GRP"))
		{
			groups.get; #Collect Groups Information
		}
		if(($app -eq "All") -or ($app -eq "TEAMS"))
		{
			teams.Get; #Collect Teams Information
		}
		if(($app -eq "All") -or ($app -eq "POWERAPPS"))
		{
			powerapps.get; #Collect Teams Information
		}		
	}
	else
	{
		if($appToProcess -eq "TENANT")
		{
			tenant.get; #Collect Exchange Information
		}
		elseif($appToProcess -eq "USERS")
		{
			users.get; #Collect Teams Information
		}
		elseif($appToProcess -eq "EXCH")
		{
			eo.get; #Collect Exchange Information
		} 
		elseif($appToProcess -eq "PF")
		{
			pf.get; #Collect Public Folder Information
		}
		elseif($appToProcess -eq "GRP")
		{
			groups.get; #Collect Groups Information
		}
		elseif($appToProcess -eq "OD")
		{
			od.get; #Collect OneDrive Information
		}
		elseif($appToProcess -eq "SP")
		{
			sharepoint.get; #Collect SharePoint Information
		}
		elseif($appToProcess -eq "TEAMS")
		{
			teams.get; #Collect Teams Information
		}
		elseif($appToProcess -eq "POWERAPPS")
		{
			powerapps.get; #Collect Teams Information
		}		
	}
}

#Load global data information
Function global.load
{
	[string]$global:adminAcct = "";
	[double]$global:exchSize = 0;
	[double]$global:archiveExchSize = 0;
	[double]$global:pfSize = 0;
	[double]$global:odSize = 0;
	[double]$global:spSize = 0;
	[double]$global:teamSize = 0;
	
	[int]$global:exchCount = 0;
	[int]$global:archiveExchCount = 0;
	[int]$global:pfCount = 0;
	[int]$global:odCount = 0;
	[int]$global:spCount = 0;
	[int]$global:teamCount = 0;
	[int]$global:groupsCount = 0;
	[int]$global:userCount = 0;
	[int]$global:blockedUserCount = 0;
	[int]$global:licensedUserCount = 0;
	[int]$global:unblockLicensedUserCount = 0;
	[int]$global:paEnvCount = 0;
	[int]$global:paFlowCount = 0;
	[int]$global:paAppCount = 0;
	
	if($debug.isPresent) #For debug information
	{
		log.info "******** DEBUG MODE ON ********" -ForegroundColor Magenta
		if($admin -eq "") #If admin information is not provided
		{
			$admin = Read-Host "Do you want to add current user as site collection admin to the sites? This is needed to search inside site collections. Enter admin account here. If you do not wish to do this, press enter.";
		}		
		log.info "Using admin account $admin" -ForegroundColor Magenta
	}
	else
	{
		#Confirm with user that global admin credentials is a requirement
		$isGA = Read-Host "To execute this utility, you need to have global administrator credentials. Press 'Y' to continue."
		if($isGA -ne "Y")#Do not proceed if user did not confirm GA perms
		{
			log.error "Stop processing as expected result was not provided";
			exit;
		}
		Write-Host "";
		if($admin -eq "") #Ask for admin information if not provided
		{
			$admin = Read-Host "Do you want to add current user as site collection admin to the sites? This is needed to search inside site collections. Enter admin account here. If you do not wish to do this, press enter.";
		}		
	}
}
#Load Program
Function environment.get
{
	log.info "Loading global data..." -f Magenta
	global.load;
	
	if(!$keeplogs.IsPresent) #Remove old logs if keep logs is not provided
	{
		log.info "Cleaning old logs"
		log.clean;
	}
	
	log.info "Performing system checks..."
	system.check; 
	
	if($app.IndexOf("#") -ne -1) #Multiple apps are provided. Loop through each app.
	{
		foreach($appToProcess in $app.Split("#"))
		{
			log.info "Processing $appToProcess..."
			app.process $appToProcess
		}
	}
	else
	{
		app.process;		
	}
	if($app -eq "All")
	{
		log.info "Generating summary..."
		summary.load; #Load summary information if all apps are needed.
	}	
	log.info "Closing log file..."
	log.close; #Close all logs
	if($email.IsPresent)
	{
		#Send Report to Druva
		$passedParams = "Tenant: $($tenant), Detailed: $($detailed.IsPresent), Apps: $($app), Output: $($output), MFA: $($mfa.IsPresent)";
		log.info $passedParams;
		output.email $passedParams;
	}
}


log.info "*******************Script Execution Started*********************"
environment.get
log.info "*******************Script Execution Ended*********************"
exit;