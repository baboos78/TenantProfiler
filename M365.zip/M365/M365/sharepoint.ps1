

Function sharepoint.load
{
	#Check if SharePoint modules are installed. Will install and import if not.
	module.check "Microsoft.Online.SharePoint.PowerShell"
	
	#module.check "PnP.PowerShell"
	
	#Register-PnPManagementShellAccess
	
	$spTenant = "https://$tenant-admin.sharepoint.com"; #Generate SharePoint admin URL
	log.info "Connecting to $spTenant..."
	if($mfa.IsPresent)
	{
		try
		{
			Connect-SPOService -Url $spTenant -ErrorAction Stop; #Connect to SharePoint Online. This will open a window for user to enter credentials.
		}
		catch
		{
			log.error "Cannot connect to SharePoint Online";
			exit;
		}
	}
	else
	{
		try
		{
			Connect-SPOService -Url $spTenant -Credential $global:cred -ErrorAction Stop;#Connect to SharePoint with credentials
		}
		catch
		{
			log.error "Cannot connect to SharePoint Online";
			exit;
		}			
	}
	
	log.success "Connected to SharePoint Online";
	Write-Host "";
}

#Get SharePoint Site Collection Details
Function sharepoint.getsitedetails($spSite, $rpt)
{
	$url = $($spSite.Url -replace "https://$tenant.sharepoint.com") -replace "https://$tenant-my.sharepoint.com"; #Reduce the length of URL to better show in report
	$title = $spSite.Title;
    $size = $spSite.StorageUsageCurrent;
	$template = $spSite.Template;
	$status = $spSite.Status;
	$lastModified = $spSite.LastContentModifiedDate;
	$owner = $spSite.Owner;
	$types = "";
	$associatedUser = "";
	if($spSite.Template -eq "SPSPERS#10") #This is a OneDrive site
	{
		$global:odSize += $size; #total OD size		
	}
	else #This is a SharePoint site. This includes group sites, team sites and collaboration sites
	{
		$global:spSize += $size; #total SP size
	}	
	
	$recycleBinSize = -1;
	$types = "";
	$errorMessage = "";
	if($libTitle -ne "")
	{
		$libSize = 0;
		$libItemCount = 0;
		$recycleBinSize = 0;
		$recycleBinItemCount = 0;
		
		$siteInfo = [Druva.Services.SharePoint.Program]::Get($spSite.Url, $libTitle); #Calling custom Druva EXE
		if($siteInfo -ne $null)
		{				
			foreach($web in $siteInfo.SPOWebs)
			{	
				$recycleBinItemCount += $web.RecycleBinItemCount;
				$recycleBinSize += $web.RecycleBinSize;
				foreach($list in $web.Lists)
				{
					$libSize += $list.SizeInBytes;
					$libItemCount += $list.FileCount;
				}
			}
			if($recycleBinSize > 0)
			{
				$recycleBinSize = $recycleBinSize /(1024*1024)
			}
			if($libSize > 0)
			{
				$libSize = $libSize /(1024*1024)
			}
			
			output.log $rpt $($title,$template,$url,$size,$status,$lastModified,$owner,"", $libSize,$libItemCount,$recycleBinSize,$recycleBinItemCount);
		}
		else 
		{
			output.log $rpt $($title,$template,$url,$size,$status,$lastModified,$owner);
		}
	}
	else
	{
		output.log $rpt $($title,$template,$url,$size,$status,$lastModified,$owner);
	}	
}
#Process SP list information which is collected dusing site loop
#*************** DRUVA TENANT PROFILER 1.0 ************
#Author: 			Babu Pillai / babu.pillai@druva.com
#Last Modified On:	04/22/2022

Function sharepoint.getlists($listsRpt, $fieldsRpt)
{
	log.success "Loading list information..."	
	output.create $listsRpt @("WebUrl", "Title","Type","FolderCount","ItemCount","FileCount","SizeInBytes","LastItemModifiedDate","LastItemDeletedDate","LastItemUserModifiedDate","StreamFileCount","StreamFileSizeInBytes","Hidden","Error");
	
	foreach($spList in $global:SiteDetails) #Loop through site details to get all list information
	{
		output.log $listsRpt $($spList.RootWebUrl, $spList.Title,$spList.Type,$spList.FolderCount, $spList.ItemCount,$spList.FileCount,$spList.SizeInBytes,$spList.LastItemModifiedDate,$spList.LastItemDeletedDate,$spList.LastItemUserModifiedDate,$spList.StreamFileCount,$spList.StreamFileSizeInBytes,$spList.IsHidden,$spList.ErrorMessage);
	}
	
	log.success "Loading list fields..."
	output.create $fieldsRpt @("WebUrl", "Title","Field Title", "Field Type");
	foreach($spList in $global:SiteDetails) #Loop through site details to get all fields information
	{
		if($debug.IsPresent){ #Just report for debug
			log.info "Found $($spList.Fields.Count) fields"
		}
		foreach($spField in $spList.Fields) #Loop through list to collect field information
		{
			if($spField.IsHidden -ne $true){ # Write only non-hidden fields
				output.log $fieldsRpt $($spList.RootWebUrl, $spList.Title, $spField.Title, $spField.Type);
			}
		}
	}	
}
#Get SharePoint site collections information of the tenant
Function sharepoint.get
{
	log.success "Loading SharePoint information...";
	
	if($libTitle -ne "")
	{
		output.create $SP_RPRT_NAME @("Title","Template","URL", "Size (MB)","Status", "Last Modified On","Owner","Error","$($libTitle) Size(MB)", "$($libTitle) Items", "RecycleBin Size (MB)","RecycleBin Items");
	}
	else
	{
		output.create $SP_RPRT_NAME @("Title","Template","URL", "Size (MB)","Status", "Last Modified On","Owner","Error");
	}
	
	try
	{
		if($siteUrl -ne "")
		{
			$spoSites = Get-SPOSite -Filter "Url -like '$siteUrl'" -Detailed | Sort-Object Title;
			Write-Host $spoSites.Count
		}
		else
		{
			if($top -eq 0) #if NO number specified by user, get all SP information
			{
				$spoSites = Get-SPOSite -IncludePersonalSite:$false -Limit All -Detailed | Sort-Object Title ;
			}
			else #if a number specified by user to collect only a number of SP sites
			{
				$spoSites = Get-SPOSite -IncludePersonalSite:$false -Limit $top -Detailed | Sort-Object Title ;
			}
		}
	}
	catch
	{
		sharepoint.load
		if($top -eq 0) #if NO number specified by user, get all SP information
		{
			$spoSites = Get-SPOSite -IncludePersonalSite:$false -Limit All -Detailed | Sort-Object Title ;
		}
		else #if a number specified by user to collect only a number of SP sites
		{
			$spoSites = Get-SPOSite -IncludePersonalSite:$false -Limit $top -Detailed | Sort-Object Title;
		}
	}
	$global:spCount = $spoSites.Count;
	if($debug.IsPresent)
	{
		log.info "Found $global:spCount Sites"
		log.info "admin: $admin"
	}
	foreach($spoSite in $spoSites) # Loop through site collections
	{
		log.success "`t$($spoSite.URL)"
		
		try 
		{
			if ($force.IsPresent) # if force is provided, add current account as SCA for better results. This can affect site modified datetime.
			{
				$admin = Set-SPOUser -Site $spoSite.URL -LoginName $admin -IsSiteCollectionAdmin $true #add user as Site collection admin
				
				sharepoint.getsitedetails $spoSite $SP_RPRT_NAME
				try
				{
					#Remove account SCA role from sitre collection
					$removeAdmin = Set-SPOUser -Site $spoSite -LoginName $admin -IsSiteCollectionAdmin $false #remove user as Site collection admin
				}
				catch
				{
					log.error $_
				}
			}
			else
			{
				sharepoint.getsitedetails $spoSite $SP_RPRT_NAME								
			}
		}
		catch
		{
			log.error $_
		}
	}
}

