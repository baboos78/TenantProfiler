#*************** DRUVA TENANT PROFILER 1.0 ************
#Author: 			Babu Pillai / babu.pillai@druva.com
#Last Modified On:	04/22/2022

#Get public folder information
Function pf.get
{
	#Create public folder report
	output.create $PF_RPRT_NAME @("Name", "Mailbox Owner", "Item Count", "Size(MB)");
	$publicFolders = $null;
	try
	{
		$publicFolders = Get-PublicFolderStatistics -ErrorAction SilentlyContinue | Sort-Object Name;
	}
	catch
	{
		eo.load;
		$publicFolders = Get-PublicFolderStatistics -ErrorAction SilentlyContinue | Sort-Object Name;
	}
	if($publicFolders -ne $null)
	{
		$global:pfCount = $publicFolders.Count;
		
		log.success "Found $($global:pfCount) public folders";
		
		foreach($publicFolder in $publicFolders) #Loop through public folders
		{
			$pfSize = convertSizeToMB $publicFolder.TotalItemSize;
			#Write to report
			output.log $PF_RPRT_NAME $($publicFolder.Name,$publicFolder.MailboxOwnerId, $publicFolder.ItemCount, $pfSize);
			
			#Collect public folder size. This will be used for global count.
			$global:pfSize += $pfSize;
		}
	}
	else
	{
		log.error "No public folders found. If you think this is a mistake, ensure current user is added to public folder root.";
	}
}
#Below function will be used to get size information from Get-MailboxStatistics. Value returned will be on MB
Function convertSizeToMB($size)
{
	$mbSize = 0;
	if($size -ne $null) 
	{
		if($size.IndexOf(" MB") -ne -1){
			$mbSize = [math]::Round([double]$size.SubString(0,$size.IndexOf(" MB")),2);
		}
		elseif($size.IndexOf(" KB") -ne -1){
			$mbSize = [math]::Round(([double]$size.SubString(0,$size.IndexOf(" KB"))) / 1024,2);
		}
		elseif($size.IndexOf(" GB") -ne -1){
			$mbSize = [math]::Round(([double]$size.SubString(0,$size.IndexOf(" GB"))) * 1024,2);
		}
		elseif($size.IndexOf(" B") -ne -1){
			$mbSize = [math]::Round(([double]$size.SubString(0,$size.IndexOf(" B"))) /(1024 *1024),2);
		}
	}
	return $mbSize;
}