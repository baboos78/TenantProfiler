#*************** DRUVA TENANT PROFILER 1.0 ************
#Author: 			Babu Pillai / babu.pillai@druva.com
#Last Modified On:	04/22/2022

Function powerapps.load
{
	module.check "Microsoft.PowerApps.Administration.PowerShell"
		
	log.info "Connecting to Power Apps Administration..."; #Prompt user to enter credentials to connect to Teams environment.
	if($mfa.IsPresent)
	{
		Add-PowerAppsAccount -Endpoint prod -ErrorAction Stop
	}
	else
	{
		$admin = $global:cred.UserName;
		Add-PowerAppsAccount -Endpoint prod -Username $global:cred.UserName -Password $global:cred.Password -ErrorAction Stop
	}
	if($_.Error)
	{
		log.error "Cannot connect to Power Apps Environment";
		exit;
	}
	log.success "Connected to Power Apps Environment";
	Write-Host "";
}

#Get PowerApps information
Function powerapps.get
{ 
	
	environments.get
	
	powerautomate.get
	
	powerapps.getapps
}
function powerapps.getapps
{
	$paApps = Get-AdminPowerApp
	$global:paAppCount = $paApps.Count
	if(($paApps -ne $null) -AND ($global:paAppCount -eq 0))
	{
		$global:paAppCount = 1;
	}
	log.success "Found $($global:paAppCount) apps...";
	output.logAsBold $PWRAPPS_RPRT_NAME "Power Apps" 9
	output.logAsBold $PWRAPPS_RPRT_NAME $("Name","Environment","Created Time");
	
	foreach($paApp in $paApps)
	{
		output.log $PWRAPPS_RPRT_NAME $($paApp.DisplayName,$paApp.EnvironmentName,$paFlow.CreatedTime);
	}
	output.log $PWRAPPS_RPRT_NAME $("");
}
Function powerautomate.get
{
	$paFlows = Get-AdminFlow -ErrorAction SilentlyContinue
	$global:paFlowCount = $paFlows.Count
	if(($paFlows -ne $null) -AND ($global:paFlowCount -eq 0))
	{
		$global:paFlowCount = 1;
	}
	log.success "Found $($global:paFlowCount) power automate flows...";
	output.logAsBold $PWRAPPS_RPRT_NAME "Power Automate" 9
	output.logAsBold $PWRAPPS_RPRT_NAME $("Name","Is Enabled","Environment Name");
	foreach($paFlow in $paFlows)
	{
		output.log $PWRAPPS_RPRT_NAME $($paFlow.DisplayName,$paFlow.Enabled,$paFlow.EnvironmentName);
	}
	output.log $PWRAPPS_RPRT_NAME $("");
}
Function environments.get
{
	$environments = Get-AdminPowerAppEnvironment -ErrorAction SilentlyContinue
	$global:paEnvCount = $environments.Count
	if(($environments -ne $null) -AND ($global:paEnvCount -eq 0))
	{
		$global:paEnvCount = 1;
	}

	output.create $PWRAPPS_RPRT_NAME @("Power Platform");
	log.success "Found $($global:paEnvCount) environments...";
	
	#output.logAsBold $PWRAPPS_RPRT_NAME "Power App Environments" 9
	#output.logAsBold $PWRAPPS_RPRT_NAME $("EnvironmentName","DisplayName", "IsDefault","Type","Location","CreatedBy");
	output.log $PWRAPPS_RPRT_NAME $("EnvironmentName","DisplayName", "IsDefault","Type","Location","CreatedBy");
	foreach($environment in $environments)
	{
		$envName = $environment.EnvironmentName
		$envDisplayName = $environment.DisplayName
		$envIsDefault = $environment.IsDefault
		$envType = $environment.EnvironmentType
		$envLoc = $environment.Location
		$envCreatedBy = $environment.CreatedBy[0].id
		
		output.log $PWRAPPS_RPRT_NAME $($envName,$envDisplayName,$envIsDefault,$envType,$envLoc,$envCreatedBy);
	}
	output.log $PWRAPPS_RPRT_NAME $("");
}