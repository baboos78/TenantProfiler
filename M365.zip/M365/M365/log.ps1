#*************** DRUVA TENANT PROFILER 1.0 ************
#Author: 			Babu Pillai / babu.pillai@druva.com
#Last Modified On:	04/08/2022

#Clean logs created as part of previous run
Function log.clean()
{
	Get-ChildItem -Path "$currentDirectory\Reports" -Include *.* -File -Recurse | foreach { $_.Delete()} #Create all contents under 'Reports' folder    
}

#Close all report files
Function log.close()
{
	if($output -eq "xls")
	{
		Write-Host "Closing report file...$global:outputFile" -ForegroundColor Magenta
		try{
			$worksheet = $global:workbook.sheets.item("Sheet1"); #Default sheet
			$worksheet.Delete(); #Delete empty Sheet
		}
		catch{
			#No default sheet found
		}
		try
		{
			$global:workbook.SaveAs($global:outputFile); #Save report file
			$global:workbook.Close($true); #Close report file
			$global:excel.DisplayAlerts = 'False'; #Avoid user alerts
			$global:excel.visible = $true; #Make object visible
			$global:excel.Quit(); #Clear object from library
		}
		catch
		{
		}
	}	
}

#Write information message
Function log.info($message)
{
	Write-Host $message -ForegroundColor Yellow;
	Add-Content -Path .\logs\log.txt -Value "$(Get-Date)`tINFO`t$message";
}
#Write success message
Function log.success($message)
{
	Write-Host $message -ForegroundColor Green;
	Add-Content -Path .\logs\log.txt -Value "$(Get-Date)`tSUCCESS`t$message";
}
#Write error message
Function log.error($message)
{
	Write-Host $message -ForegroundColor Red
	$date = Get-Date
	Write-Host "$date,$message" | Export-Csv -Path .\error.log -Append;
	Add-Content -Path .\logs\log.txt -Value "$(Get-Date)`tERROR`t$message";
	Add-Content -Path .\logs\error.txt -Value "$(Get-Date)`tERROR`t$message";
}

